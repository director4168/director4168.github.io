#!/system/bin/sh

#==========Copyright statement==========
# (C) 2025-20XX director_Carter All Rights Reserved.

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#====================

#==========联系方式 | Contact Information==========

#个人网站 | Personal website
# https://director4168.github.io

#哔哩哔哩 | BiliBili
# 昵称 | Name: director_Carter
# UID: 1113918991
# 主页 | Home page: https://b23.tv/tk7CcWA

### MT论坛 | MT Forum
# 昵称 | Name: director_mark
# UID: 134138
# 主页 | Home page: https://bbs.binmt.cc/home.php?mod=space&uid=134138&do=profile&mobile=2

#QQ
# 2705722903
# 1316983035

#邮箱 | Email
# 2705722903@qq.com
# 1316983035@qq.com
#====================


# 豆米 程序更新核心文件
# 更新配置数据来源于我的(原作者)github
# 因为配置数据来源于github，中国大陆用户可能访问较慢，需要挂梯子。
# 本人懒得写json和json解析了，所以更新配置是直接放到.html而不是.json，不过本人还是建议用json


function Fun_Update_doumi {
clear


# 检查执行环境(SHELL)
if [ ! "$DEN_SHELL" = "MT" ]; then

clear

	echo -e "\033[1;31m该模块强制使用 \033[1;31mMT管理器(正式/共存/测试)拓展包\033[1;31m 环境执行！请切换至要求环境后再执行！\033[0m"

echo "========================="
Fun_GongNeng_Zong


fi





	echo -e "\033[36m建议挂梯子，否则中国大陆用户可能访问过慢、无法访问或被拒绝请求（本人一般使用绿茶VPN）\033[0m"





# 配置数据URL
Configuration_Update_doumi="https://director4168.github.io/doumi/UpdateConfiguration.json"





# 临时目录
TMP_File_Update_configuration_doumi="$System_PWD/tmp"


# 创建临时目录，用于存放下载的配置文件
	function Fun_Shell_Mkdir {
# 递归创建临时目录
	mkdir -p $TMP_File_Update_configuration_doumi

	if [ ! -d "$TMP_File_Update_configuration_doumi" ]; then

	clear

		echo -e "\033[1;31m创建临时配置数据目录(\033[1;37m$TMP_File_Update_configuration_doumi\033[1;31m)失败！\033[0m"

		echo "========================="
	Fun_GongNeng_Zong


	fi
	}
Fun_Shell_Mkdir





# 从指定的URL获取配置数据
	echo -e "\033[1;33m正在获取配置数据中(URL: \033[1;37m$Configuration_Update_doumi\033[1;33m)...\033[0m"

UpdateConfigurationFile="$TMP_File_Update_configuration_doumi/UpdateConfiguration.json"


# 下载
curl -s -o "$UpdateConfigurationFile" "$Configuration_Update_doumi" || {
	echo -e "\033[1;31m❌获取配置数据失败！\033[m"
	echo -e "\033[31m请确保 已连接WIFI/开启数据网络 ，且 WIFI/数据网络 可用！\033[0m"

echo "========================="

Fun_GongNeng_Zong

}





# 提取json数据（防止没有jq，所以使用grep）
# 下载链接
download_URL="$(grep -oP '"download_URL"\s*:\s*"\K[^"]+' "$UpdateConfigurationFile")"
# 版本
Version="$(grep -oP '"Version"\s*:\s*"\K[^"]+' "$UpdateConfigurationFile")"
# 版本号
Version_B="$(grep -oP '"Version_B"\s*:\s*"\K[^"]+' "$UpdateConfigurationFile")"
# 源码压缩包的SHA256哈希值，为了绝对的兼容性256用wty表示，但配置数据中仍为256
ZIP_SHAwty="$(grep -oP '"ZIP_SHA256"\s*:\s*"\K[^"]+' "$UpdateConfigurationFile")"
# 通知/公告
Notice="$(grep -oP '"Notice"\s*:\s*"\K[^"]+' "$UpdateConfigurationFile")"
# 源数据
Configuration_FileText_Data=$(<"$UpdateConfigurationFile")




	echo -e "\033[1;32m已获取配置数据
\033[1;33m通知/公告: \033[1;36m$Notice\033[0m"
echo "========================="
	echo -e "\033[1;37m下载链接: \033[0m$download_URL
\033[1;37m版本: \033[0m$Version
\033[1;37m版本号: \033[0m$Version_B
\033[1;37m程序压缩包SHA256: \033[0m$ZIP_SHAwty"
# 防止显示的源数据可能包含\n、\033等内容
	echo "\033[1;37m源数据: \033[0m$Configuration_FileText_Data"

echo "========================="



# 提示对比
	echo -e "当前版本: \033[1;37m$SV\033[0m  最新配置数据中的版本: \033[1;37m$Version\033[0m
当前版本号: \033[1;37m$SVN\033[0m  最新配置数据中的版本号: \033[1;37m$Version_B\033[0m
最新程序压缩包 SHA256: \033[1;37m$ZIP_SHAwty\033[0m"



# 根据版本号判断是否需要更新
if [ ! "$Version_B" -gt "$SVN" ]; then
echo "========================="

	echo -e "\033[1;32m已是最新版，无需更新\033[0m"

# 清理临时目录
rm -rf $TMP_File_Update_configuration_doumi

echo "========================="

Fun_GongNeng_Zong


else
echo "========================="

	echo -e "\033[1;36m检测到最新版$Version($Version_B)
\033[0m"

		echo -en "下载链接: $download_URL
输入\033[1;37mY\033[0m下载(否则不下载): "
		read YN_Download_doumi

	if [ "$YN_Download_doumi" = "Y" ] || [ "$YN_Download_doumi" = "y" ]; then
# 下载程序
	curl -k -L -o "$TMP_File_Update_configuration_doumi/doumi.zip" "$download_URL" || {
		echo -e "\033[1;31m❌下载失败！请自行前往\033[1;37mhttps://wwc.lanzouq.com/b00l1vkp5a\033[1;31m(\033[1;33m密码: \033[1;37m0708\033[1;31m)下载\033[m"

	echo "========================="

	Fun_GongNeng_Zong

	}


	else
	echo "========================="

		echo -e "\033[1;31m已拒绝下载\033[0m"

	echo "========================="

	Fun_GongNeng_Zong


	fi





# 解码
# 从v5.1.0版本弃用把程序压缩包Base64编码
#base64 -d $TMP_File_Update_configuration_doumi/doumi.base64 > $TMP_File_Update_configuration_doumi/doumi.zip

# 将下载好的最新版本解压
unzip -o $TMP_File_Update_configuration_doumi/doumi.zip -d $System_PWD/

# 清理临时目录
clear

	echo "正在清理临时目录$TMP_File_Update_configuration_doumi"
rm -rf $TMP_File_Update_configuration_doumi



clear

	echo -e "\033[1;32m更新并解压完成\033[0m"
exit 7;

fi
# 再清除一遍临时目录
rm -rf $TMP_File_Update_configuration_doumi
}
#Fun_Update_doumi