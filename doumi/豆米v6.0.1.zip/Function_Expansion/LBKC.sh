#!/system/bin/sh

function Fun_FE_LBKC {
	echo "  按下换行键(Hex: 0A)继续(当然也可以随便输入一些东西然后按下换行键，但这没有任何意义)"
# 用read面临的主要原因是这里要按换行键，用其他方式太麻烦了所以直接用这个命令定义一个空的值
	read Hex_0A
}