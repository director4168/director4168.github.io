#!/system/bin/sh

# 时间和动态版权

function Fun_FE_TADC {
# 这里使用动态版权声明
CopyrightStatement_Time=`date +%Y`

# 判断年份是否等于2025，不等于则定义显示2025-xxxx
if [ "$CopyrightStatement_Time" = "2025" ];then
CopyrightStatement_Time_B="$CopyrightStatement_Time"


else
QT_A="2025"
QT_B="-"
CopyrightStatement_Time_B="$QT_A$QT_B$CopyrightStatement_Time"


fi
	echo -e "\033[1;37m(C) $CopyrightStatement_Time_B director_Carter. All Rights Reserved\033[0m"

echo "========================="
}