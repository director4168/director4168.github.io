#!/system/bin/sh

# 返回主菜单(通用)

function Fun_FE_RTMM {
clear
Fun_GongNeng_Zong
}