#!/system/bin/sh

# 最大描述符数量

ulimit -n