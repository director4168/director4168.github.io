#!/system/bin/sh

# 选择非法提示函数

# 获取该文件的上上个文件夹路径
System_PWD_SS=$(dirname $(dirname $(pwd)))
# 引入 豆米.sh (部分设备或解释器如果需要)
# 不需要时建议注释化
#source $System_PWD_SS/豆米.sh

function Fun_FE_STIPF {
	function Fun_GongNeng_FeiFa {
	clear
		echo -e "\033[31m[ERROR] 非法选择，已退回至主菜单\033[0m"
	Fun_GongNeng_Zong
	}
}