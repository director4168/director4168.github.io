#!/system/bin/sh

# 检测有没有.User，如果没有那么就清空目录/.user

function Fun_FE_DUF {
if [ ! -f "/storage/emulated/0/DouMi/.user/.User" ]; then
	rm -rf /storage/emulated/0/DouMi/.user/
	clear
fi
}