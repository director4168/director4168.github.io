#!/system/bin/sh

# (C) 2026-20XX director_Carter 保留所有权利。
# (C) 2026-20XX director_Carter All Rights Reserved.
# 请不要更改本文件任何内容，你应该创建一个新的文件用来获取服务器公告等，同时在主文件里更改调用函数。
# Please do not change any content in this file. You should create a new file to obtain server announcements, etc., and change the calling function in the main file.

# 服务器消息公告Server Message Announcement
# 服务器本体是Github(https://github.com)，这里使用的是Github Pages静态托管作为我的专属服务器
# Github代理: hub.gitmirror.com
#    类型: 添加前缀


function Fun_SMA {
# 最大超时时间
#SMA_MaximumTimeout="1"

# 服务器链接
SMA_ServerURL="https://director4168.github.io/doumi/Announcement_SMA1.json"

# 添加代理服务器链接
SMA_Agent_ServerURL="$SMA_ServerURL"



	echo -e "\033[36m正在链接服务器获取Announcement_SMA1.json数据(\033[1;37m$SMA_ServerURL\033[0;33m)...\033[0m"


# 拉取原始配置文件，不落地
SMA_JsonData="$(curl -m 1 -s -H "User-Agent: Mozilla/5.0" "$SMA_ServerURL")"

# 检查是否为空
if [ "$SMA_JsonData" = "" ]; then
	echo -e "\033[31m获取数据超时或失败！\033[0m"
	echo "你可能需要使用科学上网(梯子)才能正常获取"

	function Fun_SMA_Agent {
		echo -e "\033[36m尝试使用代理连接服务器...\033[0m"

# 链接改成代理链接
	SMA_JsonData="$(curl -m 1 -s -H "User-Agent: Mozilla/5.0" "$SMA_Agent_ServerURL")"

# 判断是否为空
	if [ "$SMA_JsonData" = "" ]; then
		echo -e "\033[31m仍然连接超时或失败！不再尝试连接\033[0m"

	return


	else
		echo -e "\033[36m正在解析配置(\033[1;37m系统环境可能不支持\033[0;36m)...\033[0m"


	fi
	}
# 如果要启用代理就不注释，否则则注释
#Fun_SMA_Agent

return


else
	echo -e "\033[36m正在解析配置(\033[1;37m系统环境可能不支持\033[0;36m)...\033[0m"


fi




# 查看源数据，正常情况下注释化关闭
#	echo -e "=====源数据=====\n$SMA_JsonData\n================"


# 解析
	echo -e "======\033[1;37m公告\033[0m======
$(echo "$SMA_JsonData" | grep -oP '"Announcement"\s*:\s*"\K[^"]+')"
	echo -e "======\033[1;37m其他\033[0m======
$(echo "$SMA_JsonData" | grep -oP '"Announcement"\s*:\s*"\K[^"]+')
================"


echo "========================="
}
#Fun_SMA