#!/system/bin/sh

# 登录

function Fun_RL_Login {
# 检测用户名文件、密码文件是否存在
# 用户名
	if [ ! -f "/storage/emulated/0/DouMi/user/.Username.data" ]; then
		echo -e "\033[1;31m[ERROR] 没有用户名文件(.Username.data)!\033[0m"
		echo -e "\033[1;33m[ERROR] 请在目录 \033[1;37m/storage/emulated/0/DouMi/user/\033[1;33m 执行 \033[1;37m删除账户.sh\033[1;33m 或 \033[1;37m手动删除目录所有文件\033[0m"
exit 3;
	fi

# 密码
	if [ ! -f "/storage/emulated/0/DouMi/user/.Password.data" ]; then
		echo -e "\033[1;31m[ERROR] 没有密码文件(.Password.data)!\033[0m"
		echo -e "\033[1;33m[ERROR] 请在目录 \033[1;37m/storage/emulated/0/DouMi/user/\033[1;33m 执行 \033[1;37m删除账户.sh\033[1;33m 或 \033[1;37m手动删除目录所有文件\033[0m"
exit 3;
	fi


User_NiCheng_Data=$(<"/storage/emulated/0/DouMi/user/.Username.data")
sleep 0.3
	echo "<DouMi> 嘿，$User_NiCheng_Data，输入一下密码吧。"
		echo -ne "\033[1;37m密码: \033[0m"
		read User_Password

# 读取密码文件中的SHA256哈希加密文本
User_Password_Data=$(<"/storage/emulated/0/DouMi/user/.Password.data")
# 将输入内容进行10次SHA256哈希加密
while_B=1
Password_UTF_SHA_while_B="$User_Password"
while [ $while_B -lt 11 ]
do
Password_UTF_SHA_while_B=$(printf "%s" "$Password_UTF_SHA_while_B" | sha256sum | awk '{print $1}')
# 用来人工确认不重复，不用时注释化
#echo "$while_B次: $Password_UTF_SHA_while_B"
((while_B++))
done


# 判断输入内容的SHA256哈希加密文本是否等于密码文件中的SHA256哈希加密文本
	if [ "$Password_UTF_SHA_while_B" = "$User_Password_Data" ]; then
	User_DL=OK

	else
		echo "<DouMi> $User_NiCheng_Data，你的密码好像输入错了诶，退出去重新输入吧。"
		echo -e "*注: 忘记密码可以执行\033[1;37m/storage/emulated/0/DouMi/user/\033[0m下的\033[1;37m.删除账户.sh\033[0m删除账户或手动删除\033[1;37m/storage/emulated/0/DouMi/user/\033[0m文件夹"
		exit 4;
	fi
}