#!/system/bin/sh

# 注册

function Fun_RL_Register {
# 检查本地是否有DouMi文件
	if [ -f "/storage/emulated/0/DouMi" ]; then
		echo -e "\033[1;31m[ERROR] /storage/emulated/0/目录包含 DouMi 文件，与豆米的数据目录 \033[1;37m/DouMi\033[1;33m 文件夹冲突，为确保正常运行，请将该文件重命名、移动或删除。\033[0m"
		echo -e "\033[1;31m[ERROR] 文件位置: \033[1;37m/storage/emulated/0/DouMi033[0m"
	exit 1;
	fi


# 防止目录不干净
rm -rf /storage/emulated/0/DouMi/user/


	echo "<DouMi> 你好像还没注册过诶。"
sleep 0.85
	echo "<DouMi> 先注册一下吧。"
	sleep 1.04
	echo -e "<DouMi> 你想要什么样的昵称呢？请在下面输入吧(\033[1;37m注: 注册信息保存在本地\033[0m)。"
	echo -e "\033[1;33m[USER SYSTEM] 用户名支持为空，但不建议\033[0m"
		echo -ne "\033[1;37m你的昵称: \033[0m"
		read NiCheng_ShuRu_user
			if [ "$NiCheng_ShuRu_user" = "DouMi" ]; then
			sleep 0.62
				echo "<DouMi> 哈哈，你怎么用我的名字呢？不可以哦，至少要把大小写给改一改嘛，再给你一次机会，不然我就要生气了。"
					echo -ne "\033[1;37m你的昵称(\033[1;3;37m别用我名字了\033[1;37m): \033[0m"
					read NiCheng_ShuRu_user_A
				if [ "$NiCheng_ShuRu_user_A" = "DouMi" ]; then
					sleep 0.62
						echo "<DouMi> 你怎么还用我的名字呢？我生气了，立刻终止！"
					exit 6;
					else
					sleep 0.62
						echo "<DouMi> 这还差不多。"
					NiCheng_ShuRu_user=$NiCheng_ShuRu_user_A
				fi
			fi


# 判断是否有指定目录，如果没有则创建目录(user顺便也弄一下)
	if [ ! -d "/storage/emulated/0/DouMi/user/" ]; then
	mkdir -p /storage/emulated/0/DouMi/user/
	fi

# 检查是否创建成功
	if [ ! -d "/storage/emulated/0/DouMi/user/" ]; then
		echo -e "\033[1;31m用户目录创建失败!请手动在'\033[1;33m/storage/emulated/0/\033[1;31m'下创建'\033[1;33m/DouMi/user/\033[1;31m'文件夹及子文件夹，并手动在目录下创建'\033[1;33muser\033[1;31m'文件!\033[0m"
	exit 2
	fi


# 在目录创建提示文件
touch /storage/emulated/0/DouMi/user/.此目录信息.txt
# 在文件中写入内容
printf "该目录存放“豆米”的账号信息，包括但不限于账号声明文件(.User)、用户名(.Username.data)、密码(.Password.data)。\n删除这些文件，即代表注销。\n账号声明文件(.User)用于声明用户名、密码等合法，若没有该文件那么执行“豆米”将会删除默认用户数据目录及其所有子文件/夹。" > "/storage/emulated/0/DouMi/user/.此目录信息.txt"


# 在目录创建删除账号文件
touch /storage/emulated/0/DouMi/user/.删除账户.sh
# 在文件中写入内容
printf "#!/bin/bash\nrm -rf /storage/emulated/0/DouMi/user/" > "/storage/emulated/0/DouMi/user/.删除账户.sh"


# 在目录创建.User文件
touch /storage/emulated/0/DouMi/user/.User
	if [ -f "/storage/emulated/0/DouMi/user/.User" ]; then
	printf "账户声明文件，用于声明账户合法，删除该文件则代表删除账户。" > "/storage/emulated/0/DouMi/user/.User"
	else
		echo -e "\033[1;31m注册失败!\033[1;37m.User\033[1;31m账户声明文件创建失败\033[0m"
	exit 2;
	fi


# 判断两种用户名值是否相等，如果不相等那么则设为相等
	if [ "$NiCheng_ShuRu_user_A" = "$NiCheng_ShuRu_user" ]; then
	NiCheng_ShuRu_user=$NiCheng_ShuRu_user_A
	fi
# 以下用来人工判断两个值是否相等，这两个值的作用可以根据上方代码判断，不用时注释
#echo "A: $NiCheng_ShuRu_user_A"
#echo "No A: $NiCheng_ShuRu_user"

# 将用户名保存起来
printf "$NiCheng_ShuRu_user" > "/storage/emulated/0/DouMi/user/.Username.data"

# 检测用户名是否保存成功
	if [ ! -f "/storage/emulated/0/DouMi/user/.Username.data" ]; then
		echo -e "\033[1;31m保存失败!\033[1;37m.Username.data\033[1;31m用户名文件创建失败\033[0m"
		exit 2;
	fi

# 设置密码
sleep 1
	echo "<DouMi> 为你的账号($NiCheng_ShuRu_user)设一个密码吧！"
	echo -e "\033[1;33m[USER SYSTEM] 密码支持为空，但不建议\033[0m"
		echo -ne "\033[1;37m您的密码(\033[1;3;4;37m可包含特殊字符\033[1;37m): \033[0m"
		read Password_ShuRu_user

# 对密码进行10次sha256哈希加密
Password_user_while_A="$Password_ShuRu_user"
while_A=1
while [ $while_A -lt 11 ]
do
Password_user_while_A=$(printf "%s" "$Password_user_while_A" | sha256sum | awk '{print $1}')
# 用来人工确认不重复，不用时注释化
#echo "$while_A次: $Password_user_while_A"
((while_A++))
done

# 将密码保存起来
printf "$Password_user_while_A" > "/storage/emulated/0/DouMi/user/.Password.data"

# 检测密码文件是否存在
	if [ ! -f "/storage/emulated/0/DouMi/user/.Password.data" ]; then
		echo -e "\033[1;31m保存失败!\033[1;37m.Password.data\033[1;31m密码文件创建失败\033[0m"
		exit 2;
	else
	sleep 0.8
		echo -e "<DouMi> 嘿，$NiCheng_ShuRu_user，你的密码已经设为 \033[1m$Password_ShuRu_user\033[0m 了。"
		echo "<DouMi> 退出去重新输入一下密码吧。"
		exit 5;
	fi
}