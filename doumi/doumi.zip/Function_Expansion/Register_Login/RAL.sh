#!/system/bin/sh

# 注册和登录
# 调用作用


# 判断之前是否注册过，如果没有则注册（其实就是判断有没有指定的文件）

function Fun_RL_RAL {

if [ ! -f "/storage/emulated/0/DouMi/user/.User" ]; then
# 注册
Fun_RL_Register





else
# 登录
Fun_RL_Login





fi
}