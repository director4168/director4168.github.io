#!/system/bin/sh

# 作者和更新、介绍

function Fun_FE_AAUI {
echo "========================="

	echo "By (BiliBili): director_Carter"
	echo -e "作者哔哩哔哩账号首页链接: \033[1;37mhttps://b23.tv/4eRfs8Y\033[0m"
	echo "By (MT论坛): director_mark"
	echo -e "作者MT论坛账号首页链接: \033[1;37mhttps://bbs.binmt.cc/home.php?mod=space&do=profile\033[0m"
	echo -e "By (个人网站): \033[1;37mhttps://director4168.github.io\033[0m"


echo "========================="


	echo -e "更新链接: \033[1;36mhttps://wwc.lanzouq.com/b00l1vkp5a\033[0m
提取码: \033[1;31m0708\033[0m"

echo "========================="

	echo -e "\033[1;33m程序使用\033[1;37mMPL-2.0\033[1;33m开源协议\033[0m"

	echo -e "\033[1;36m请确保在使用本工具前已仔细阅读《LICENSE》 及 《NOTICE.md》。如若修改并严格遵守MPL-2.0开源协议\033[0m"
echo "========================="
}