#!/system/bin/sh

# 检测与调试
# 检测执行环境&Root执行状态、部分调试信息

function Fun_FE_TAD {
# 因为如果不使用root权限去检查SHELL，返回的结果可能为空，但PATH不会，所以系统环境是检查PATH
if [ "$PATH" = "/sbin:/system/sbin:/product/bin:/apex/com.android.runtime/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37m系统\033[1;33m 环境执行\033[0m"
	echo -e "\033[1;36m推荐使用 \033[1;37mMT管理器(正式/共存/测试)拓展包\033]1;36m 环境执行\033[0m"

DEN_SHELL="SYSTEM"


elif [ "$SHELL" = "/data/user/0/bin.mt.plus/files/term/bin/bash" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37mMT管理器正式版拓展包\033[1;33m 环境执行\033[0m"

DEN_SHELL="MT"


elif [ "$SHELL" = "/data/user/0/bin.mt.plus.canary/files/term/bin/bash" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37mMT管理器共存/测试版拓展包\033[1;33m 环境执行\033[0m"

DEN_SHELL="MT"


elif [ "$SHELL" = "/data/data/com.termux/files/usr/bin/bash" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37mTermux\033[1;33m 环境执行\033[0m"
	echo -e "\033[1;36m推荐使用 MT管理器(正式/共存/测试)拓展包 环境执行\033[0m"

DEN_SHELL="TERMUX"


else
	echo -e "\033[1;33m未知的软件执行环境
SHELL: \033[1;37m$SHELL\033[1;32m
PATH: \033[1;37m$PATH\033[0m"
	echo -e "\033[1;36m推荐使用 \033[1;37mMT管理器(正式/共存/测试)拓展包\033[1;36m 环境执行\033[0m"

DEN_SHELL="NULL"


fi


echo "========================="
# 检测Root
if [ ! "$(id -u)" = "0" ]; then
	echo -e "\033[1;33m工作模式: \033[1;37m无ROOT\033[1;33m(\033[37m适合本程序几乎所有功能稳定运行\033[33m)\033[0m"


else
	echo -e "\033[1;33m工作模式: \033[1;37mROOT\033[1;33m(\033[37m不建议的工作模式，除非无ROOT无法执行\033[33m)\033[0m"


fi


echo "========================="
# 调试信息
	function Fun_DEN_Debug {
		echo -e "调试信息(TAD模块)
时间: $(date +"%Y-%m-%d %H:%M:%S:%N")

\033[1;37mDEN_SHELL\033[0m: $DEN_SHELL
"

	# 部分运行信息
	ps -p $$

		echo -e "
\033[1;37mPATH\033[0m: $PATH
\033[1;37mSHELL\033[0m: $SHELL
"

	# 最大描述符数量(影响例如source最多套嵌)
		echo -e "\033[1;37m最大描述符数量\033[0m: $(ulimit -n)
"


# 部分系统属性
		echo -e "\033[1;36m部分系统属性\033[0m:
\033[1;37m系统版本\033[0m: $(getprop ro.build.version.release)
\033[1;37m操作系统(执行系统)\033[0m: $(uname -s)
\033[1;37m内核版本\033[0m: $(uname -r)
\033[1;37m网络节点主机名\033[0m: $(uname -n)
\033[1;37m系统硬件架构\033[0m: $(uname -m)
\033[1;37m操作系统名称(执行系统)\033[0m: $(uname -o)
"


echo "========================="


	}
# 调试信息函数，前提是需启用Fun_FE_TAD函数
#Fun_DEN_Debug


}

# 调试信息函数(需同时启用下面这两个)，除非在Fun_FE_TAD函数内已启用
# 如若Fun_FE_TAD函数内已启用Fun_DEN_Debug函数，则只需要启动Fun_FE_TAD函数
#Fun_FE_TAD
#Fun_DEN_Debug