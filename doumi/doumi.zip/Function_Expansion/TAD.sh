#!/system/bin/sh

# 检测与调试
# 检测执行环境&Root执行状态、部分调试信息

Fun_FE_TAD() {
# 检测执行环境
if [ "$PATH" = "/sbin:/system/sbin:/product/bin:/apex/com.android.runtime/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37m系统\033[1;33m 环境执行\033[0m"
	echo -e "\033[1;36m推荐使用 MT管理器(正式/共存/测试)拓展包 环境执行\033[0m"

DEN_SHELL="SYSTEM"


elif [ "$SHELL" = "/data/user/0/bin.mt.plus/files/term/bin/bash" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37mMT管理器正式版拓展包\033[1;33m 环境执行\033[0m"

DEN_SHELL="MT"


elif [ "$SHELL" = "/data/user/0/bin.mt.plus.canary/files/term/bin/bash" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37mMT管理器共存/测试版拓展包\033[1;33m 环境执行\033[0m"

DEN_SHELL="MT"


elif [ "$SHELL" = "/data/data/com.termux/files/usr/bin/bash" ]; then
	echo -e "\033[1;33m当前使用 \033[1;37mTermux\033[1;33m 环境执行\033[0m"
	echo -e "\033[1;36m未经测试的执行环境。推荐使用 MT管理器(正式/共存/测试)拓展包 环境执行\033[0m"

DEN_SHELL="TERMUX"


else
	echo -e "\033[1;33m未知执行环境"
	echo -e "SHELL: \033[1;37m$SHELL\033[0m"
	echo -e "PATH: \033[1;37m$PATH\033[0m"
	echo -e "\033[1;36m推荐使用 MT管理器拓展包 环境执行\033[0m"
DEN_SHELL="NULL"


fi

echo "========================="

# Root 检测
if [ "$(id -u)" -ne 0 ]; then
	echo -e "\033[1;33m工作模式: \033[1;37m无ROOT\033[1;33m(适合本程序几乎所有功能)\033[0m"


else
	echo -e "\033[1;33m工作模式: \033[1;37mROOT\033[1;33m(不推荐，除非无ROOT无法执行)\033[0m"


fi


echo "========================="


# 调用调试信息函数，不使用注释，默认注释掉
#Fun_DEN_Debug
}



# 调试函数
Fun_DEN_Debug() {
	echo -e "调试信息"
	echo -e "时间: $(date +"%Y-%m-%d %H:%M:%S")"

	echo -e "DEN_SHELL: $DEN_SHELL"

	ps -p $$

	echo -e "PATH: $PATH"
	echo -e "SHELL: $SHELL"

	echo -e "最大描述符数量: $(ulimit -n)"

	echo -e "系统属性:"
	echo -e "  系统版本: $(getprop ro.build.version.release)"
	echo -e "  内核版本: $(uname -r)"
	echo -e "  硬件架构: $(uname -m)"


echo "========================="
}