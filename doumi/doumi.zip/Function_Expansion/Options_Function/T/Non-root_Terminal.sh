#!/system/bin/sh

# 二级菜单-打开终端(非ROOT)

function Fun_OF_T_NrT {
clear

	echo -e "\033[1;33m系统环境(/system/bin/sh)不使用ROOT可能会失败\033[0m"

# 提取并定义新的SHELL
SHELL_JX=$(dirname "$SHELL")/

# 将工作路径切换到此
cd $SHELL_JX

#提取并定义SHELL的文件名
SHELL_JX_B=${SHELL##*/}

# 执行新的SHELL
./$SHELL_JX_B
}