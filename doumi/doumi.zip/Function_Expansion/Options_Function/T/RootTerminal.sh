#!/system/bin/sh

# 二级菜单-ROOT终端

function Fun_OF_T_RT {
if [ `id -u` -ne 0 ]; then
clear
	echo -e "\033[1;31mNO ROOT\033[0m"
Fun_GongNeng_Zong


else
# 将SHELL设为/system/bin/sh
SHELL=/system/bin/sh
clear
	echo -e "终端模式(\033[1;37mROOT终端\033[0m)"
	echo "PATH与SHELL使用 /system/bin/sh (安卓默认，可使用命令更改)"
	echo -e "\033[31m该终端为已获取\033[1;31mROOT\033[0;31mm权限的终端，因此\033[1;31m请勿输入危险代码\033[0m"
# 使用su命令(必须有ROOT)切换为终端(目前仅在安卓设备上测试)
su
fi
}