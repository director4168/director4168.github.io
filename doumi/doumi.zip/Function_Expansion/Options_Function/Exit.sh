#!/system/bin/sh

# 退出脚本
# 这一个的1和2菜单懒得弄分层了，所以直接套在这个文件里吧，反正内容较少

function Fun_OF_Exit {
clear
	echo "<DouMi> 嗯……"
	sleep 0.6
	echo "<DouMi> $User_NiCheng_Data，你确定退出吗？"
	sleep 0.35

# 退出脚本-次级菜单
PS3="输入序号: "
select menu in 确定退出 返回至主菜单;do
case $REPLY in 
1)
# 退出脚本-确定退出

clear
	echo "<DouMi> 再见，$User_NiCheng_Data"
exit 7;





  ;;
2)
# 退出脚本-返回至主菜单

clear
	echo "[SYSTEM] 已返回"
Fun_GongNeng_Zong





      ;;
    *)
# 选择非法-退出脚本
claer

Fun_GongNeng_FeiFa





esac
done
}