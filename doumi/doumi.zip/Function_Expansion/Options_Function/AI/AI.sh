#!/system/bin/sh

# AI
#By director_Carter

function Fun_OF_AI {
clear


	echo -e "使用青云客AI
如需返回请输入exit"


echo "========================="


# 定义使用的AI模型的URL(原版使用青云客)
AI_URL="http://api.qingyunke.com/api.php?key=free&appid=0"


# AI你问我答
	function Fun_AI_SF {
			echo -en "\033[1;37m<$User_NiCheng_Data>(你)\033[0m: "
			read ShuRu_AI


	# 判断输入是否有特殊意义
	if [ "$ShuRu_AI" = "exit" ]; then
	clear

	Fun_GongNeng_Zong


	else
	# 发送数据包
	AI_Fa=$(curl -s "$AI_URL&msg=$ShuRu_AI")
	# 接收数据包
	AI_Fan=$(echo "$AI_Fa" | sed -n 's/.*"content":"\([^"]*\)".*/\1/p')

	# 反馈给用户
		echo -e "<青云客AI> $AI_Fan"


	fi

	# 开启下一轮
	Fun_AI_SF
	}
Fun_AI_SF


}
#Fun_OF_AI