#!/system/bin/sh

# 全自动脱壳工具
# 该工具来源于网络搜集
# 25092118-G

function Fun_OF_TO_ASU {

input_file() {
	[ ! -f "$file" ] && exit
	chmod +x "$file"
	[ ! -x "$file" ] && exit
	[[ "$file" != */* ]] && file="./$file"
}
ELF(){
{
[ $SHELL != /system/bin/sh ] && error
[ -z $file ] && error
[ ! -f $file ] && error
chmod +x $file
[ ! -x $file ] && error
! grep -q / <<< $file && file=./$file
input_file
mkdir -p tmp1/tmp/tmp tmp2
$file & (sleep 0.02s ;tmp3=$!)
mount tmp1 /data/user/0
mount tmp1 /data/app
time=`date +%s`
until [ $((`date +%s` - $time)) -ge 2 ]
do
 cp -rf /data/user/0/* tmp2
 cp -rf /data/app/* tmp2
done
kill -9 $tmp3 $(pidof `basename $file`)
for i in `find tmp2 -type f`
do
 i=`basename $i`
 ! [[ $i = su || $i = .os ]] && kill -9 `pgrep -f $i`
done
for i in `pgrep -f sh bash toybox busybox`
do
 [[ $i -ne $$ && $i -ne $(printf `ps $$ -o ppid=`) ]] && kill -9 $i
done
umount /data/user/0
umount /data/app
mv `find tmp2 -type f` ${file%/*}
rm -rf tmp1 tmp2
}>/dev/null 2>&1
}

echo -n 请输入文件路径:&read file
if file "$file" | grep -qi "ELF"; then
echo 开始落地拦截
ELF
if [ $? -eq 1 ]; then
echo 拦截成功
echo 文件已输出
fi
echo 拦截失败进行dump
        input_file
		ulimit -c 102400
		corp=/proc/sys/kernel/core_pattern
		core=`cat $corp`
		echo "${file%/*}/core.%e.%p" > $corp
		"$file" &
		sleep 0.02s
		kill -SIGSEGV $!
		sleep 1
		echo $core > $corp
		ulimit -c 0
		if [ $? -eq 0 ]; then
        echo dump成功
        echo 文件已输出
        fi
else
base64_vt=$(grep -i -E 'eval.*base64|base64.*eval' "$file" | wc -l)
if [ "$base64_vt" -ge 2 ]; then
echo "检测到为base64变异"
while IFS= read -r line || [ -n "$line" ]; do
    matched_line=$(echo "$line" | grep -o 'echo.*=')
    if [ ! -z "$matched_line" ]; then
        echo "$matched_line" >> output.txt
    fi
done < $file
source_file="output.txt";target_file="9999"
line_minus_one=$(tail -n 1 "$source_file")
if [[ $line_minus_one == echo* && $line_minus_one == *=* ]]; then
echo -n "$line_minus_one" >> "$target_file"
echo -n '" | base64 -d > 555' >> "$target_file"
 else
echo "$line_minus_one" >> "$target_file"
fi
rm output.txt&&sed 's/echo//g' 9999 > 8888&&rm 9999
new_content='echo "';target_file="8888"
sed -i '1s/^[ \t]*//' "$target_file"
sed -i "1s/^/$new_content/" "$target_file"
(chmod +x 8888;./8888;rm 8888)
target_file="555"
echo -n ' | xxd -p > 444' >> "$target_file"
file_path="555"
if [ -f "$file_path" ]; then
modified_content=$(sed 's/eval//g' "$file_path")
echo "$modified_content" > "$file_path"    
new_content='\necho ';target_file="555"
sed -i '1s/^[ \t]*//' "$target_file"
sed -i "1s/^/$new_content/" "$target_file"
cp $file 3333;target_file="3333"
last_line=$(tail -n 1 "$target_file")
if [[ $last_line == eval* && $last_line == *-d\) ]]; then
    sed -i '$d' "$target_file"   
else
    echo "未知错误！" &&exit 1
fi
(cat 555 >> 3333;rm 555;chmod +x 3333;./3333;rm 3333)
xxd -r -p 444 > "base64分段已解密.sh";rm 444
fi
echo 文件已输出
else
first_line=$(head -n 1 "$file")
if echo "$first_line" | grep -q "shell加密By Spra"; then
echo 检测到为spar压缩壳
input_111=0
progress=$((input_111 * 100 / 300))
progress_width=40
input_file=$(basename "$file")
dir_size=0
{
while [ $dir_size -eq 0 ]; do
    tail -n +$input_111 "$file" 2>/dev/null | gzip -cd 2>/dev/null >"tmp$input_file"
    input_666="tmp$input_file"
    dir_size=$(du -s "$input_666" | cut -f1)
    if [ $dir_size -eq 0 ]; then
        rm -r "$input_666"
        if [ $input_111 -gt 300 ]; then
            killall -9 $$
        else       
            ((input_111++))
            progress=$((input_111 * 100 / 300))
            update_progress $progress
        fi
    else
        mv "tmp$input_file" tmp1
    fi
done
} >/dev/null 2>&1
script_path=tmp1 
first_line=$(head -n 1 "$script_path")
modified_line=$(echo "$first_line" | sed 's/^.*MW/MW/')
sed -i "1s|.*|$modified_line|" "$script_path"
base64 -d tmp1 >tmp2 && rm -f tmp1
xxd -rp tmp2>tmp3.gz && rm -f tmp2
gzip -cd tmp3.gz>tmp4 &&rm -f tmp3.gz
file_path=tmp4
first_line=$(head -n 1 "$file_path")
modified_line=$(echo "$first_line" | sed 's/^.*sdcard_rw\s*//')
sed -i "1s|.*|$modified_line|" "$file_path"
base64 -d tmp4>tmp5 && (rm -f tmp4 & mv -f tmp5 spar压缩壳已解密.sh)
echo 文件已输出
exit
fi
        echo "file=$file">111.sh
        echo '
        PATH=/data/data/com.termux/files/usr/bin
        decode() {
            for i in $(seq $(wc -l < "$file"))
            do
                tail -n +$i "$file" | $1 > "$file+" && exec "$0" "$file+"
            done
        } 2>/dev/null
        while IFS= read -r line
        do
            case "$line" in
                *"gzip "*"d"*)
                    decode "gzip -d" "gzip解压缩"
                ;;
                *"bunzip"*|*"bzcat"*)
                    decode "bzcat" "bzip2解压缩"
                ;;
                *"tar -"*)
                    decode "tar -xzvf - -C \"${file%/*}\"" "tar解压缩"
                ;;
                *"base64 -d"*)
                    decode "base64 -d" "base64解编码"
                ;;
                *"xxd "*"r"*)
                    decode "/system/bin/xxd -r -p" "xxd解编码"
                ;;
            esac
            let d++
            [ $d -gt 100 ]
        done < "$file"
        ' >>111.sh
        /data/data/com.termux/files/usr/bin/bash 111.sh
if [ $? -eq 127 ]; then
echo 检测到为压缩类/转码类
(rm -f 111.sh;echo 文件已输出;exit 0)
else
echo 检测到为定量包
rm -f 111.sh
cat $file > 88.sh
sed -i 's/"\\";/"\\"";/g' 88.sh
sed -i 's/eval/echo/g' 88.sh
sh "88.sh" > 定量包已解密.sh
rm 88.sh
echo 文件已输出
fi
fi
fi

}