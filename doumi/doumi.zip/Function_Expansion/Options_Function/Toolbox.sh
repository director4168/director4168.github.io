#!/system/bin/sh

# 工具箱

# 全自动脱壳(素材来源于网络)
source $OF/TO/AutomaticShellUnwrap.sh

function Fun_OF_TO {
clear


PS3="请选择功能: "
select menu in 全自动脱壳 返回;do
case $REPLY in 
1)
	echo -e "\033[1;36m此全自动脱壳工具来源于网络搜集，如有侵权，请联系本人(\033[1;37m2705722903@qq.com\033[1;36m)，本人在看到并确认之后会立刻删除侵权版本\033[0m"
Fun_OF_TO_ASU





  ;;
2)
	echo -e "\033[33m已返回至主菜单\033[0m"
Fun_OF_AO_I





  ;;
*)
	echo -e "\033[31m输入非法！已自动退回这主菜单！\033[0m"

Fun_OF_AO_I




esac
done


}