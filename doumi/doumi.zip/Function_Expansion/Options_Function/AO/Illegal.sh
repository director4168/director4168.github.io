#!/system/bin/sh

# 选择非法-一级菜单次级菜单

# 引入所需文件
source $FE/Error/STIPF.sh

function Fun_OF_AO_I {
clear
Fun_GongNeng_FeiFa
}