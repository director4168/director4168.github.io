#!/system/bin/sh

function Fun_OF_AO_CP {
clear
	echo -e "\033[33m[USER SYSTEM] 更改密码\033[0m"

		echo -n "请输入新密码: "
		read User_Password_NEW

	echo "<DouMi> USER SYSTEM 正在处理密码"

# 十次SHA256加密
while_C=1
Password_UTF_SHA_while_C="$User_Password_NEW"
while [ $while_C -lt 11 ]
do
Password_UTF_SHA_while_C=$(printf "%s" "$Password_UTF_SHA_while_C" | sha256sum | awk '{print $1}')
	((while_C++))
done

	rm -r /storage/emulated/0/DouMi/user/.Password.data
	printf "$Password_UTF_SHA_while_C" > "/storage/emulated/0/DouMi/user/.Password.data"
	echo -e "\033[33m[USER SYSTEM] Hi，$User_NiCheng_Data，新的密码已保存，退出程序重新输入\033[0m"
exit 5;
}