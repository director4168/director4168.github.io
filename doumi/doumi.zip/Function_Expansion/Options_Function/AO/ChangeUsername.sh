#!/system/bin/sh

# 账户操作-更改用户名

function Fun_OF_AO_CU {
clear
	echo -e "\033[33m[USER SYSTEM] 更改用户名\033[0m"

		echo -n "请输入新用户名: "
		read User_username_NEW

if [ "$User_username_NEW" = "DouMi" ]; then
	echo "<DouMi> 不要用我名字啊喂，那就简简单单退出吧"
exit 6;
fi

	rm -r /storage/emulated/0/DouMi/user/.Username.data
	printf "$User_username_NEW" > "/storage/emulated/0/DouMi/user/.Username.data"
	echo -e "\033[33m[USER SYSTEM] Hi，$User_NiCheng_Data，新的用户名已保存，退出程序重新加载\033[0m"
exit 5;
}