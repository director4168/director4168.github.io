#!/system/bin/sh

# 账户操作-注销账户

function Fun_OF_AO_L {
clear
min=1
max=9999
ShengCheng_SuiJiShu=$((RANDOM % (max - min + 1) + min))

	echo -e "\033[33m[USER SYSTEM] 这是\033[1;31m注销账号\033[0;33m的选项，如果能放弃注销请输入不正确的注销验证码\033[0m"
	echo -e "\033[31m[USER SYSTEM] 注销验证码: \033[1;31m$ShengCheng_SuiJiShu\033[0m"
		echo -n "[USER SYSTEM] 请输入验证码注销: "
		read USER_ZhuXiao_YN


if [ "$USER_ZhuXiao_YN" = "$ShengCheng_SuiJiShu" ]; then
	rm -rf /storage/emulated/0/DouMi/user/
	echo -e "\033[31m[USER SYSTEM] 注销成功，退出脚本\033[0m"
exit 5;

else
clear
	echo -e "\033[31m[USER SYSTEM] 输入错误，取消注销并退回至主菜单\033[0m"
Fun_GongNeng_Zong
fi
}