#!/system/bin/sh

# 二级菜单

# 引入所需文件
# ROOT终端
source $OF/T/RootTerminal.sh
# 非ROOT终端
source $OF/T/Non-root_Terminal.sh

function Fun_OF_T {
clear

	echo "<DouMi> 请选择吧"
    PS3="输入序号: "
    select menu in 打开ROOT终端 非ROOT终端 返回至主菜单;do
    case $REPLY in 
    1)
# 二级菜单-ROOT终端
Fun_OF_T_RT





      ;;
    2)
# 二级菜单-打开终端(拓展包)
Fun_OF_T_NrT





  ;;
    3)
# 终端...-返回至主菜单
Fun_FE_RTMM





      ;;
    *)
# 选择非法-终端...次级菜单
Fun_GongNeng_FeiFa


    esac
    done
}