#!/system/bin/sh

# 一级菜单

# 引入所需文件
# 非法
source $OF/AO/Illegal.sh
# 注销
source $OF/AO/Logout.sh
# 修改密码
source $OF/AO/ChangePassword.sh
# 修改用户名
source $OF/AO/ChangeUsername.sh

function Fun_OF_AO {
# 一级菜单次菜单

clear

    echo "<DouMi> 请选择吧"
    PS3="输入序号: "
    select menu in 注销账户 修改密码 修改用户名 返回至主菜单;do
    case $REPLY in 
    1)
# 账户操作-注销账户
Fun_OF_AO_L





       ;;
    2)
# 账户操作-更改密码
Fun_OF_AO_CP





      ;;
    3)
# 账户操作-更改用户名
Fun_OF_AO_CU




      ;;
    4)
# 返回主菜单
Fun_FE_RTMM





      ;;
  *)
# 选择非法-一级菜单次级菜单
Fun_OF_AO_I





    esac
    done
}