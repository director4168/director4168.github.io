#!/ststem/bin/sh

# AI

source $OF/AI/AI.sh
# 测试，因为制作的时候出bug了，为防止后面会用到先不删了
#source $(pwd)/AI/AI.sh

function Fun_OF_AI_Z {
# 直接调用其函数
Fun_OF_AI


}
# 测试，………
#Fun_OF_AI