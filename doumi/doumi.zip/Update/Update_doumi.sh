#!/system/bin/sh

#==========Copyright statement==========
# (C) 2025-20XX director_Carter All Rights Reserved.

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#====================

#==========联系方式 | Contact Information==========

#个人网站 | Personal website
# https://director4168.github.io

#哔哩哔哩 | BiliBili
# 昵称 | Name: director_Carter
# UID: 1113918991
# 主页 | Home page: https://b23.tv/tk7CcWA

### MT论坛 | MT Forum
# 昵称 | Name: director_mark
# UID: 134138
# 主页 | Home page: https://bbs.binmt.cc/home.php?mod=space&uid=134138&do=profile&mobile=2

#QQ
# 2705722903
# 1316983035

#邮箱 | Email
# 2705722903@qq.com
# 1316983035@qq.com
#====================


# 豆米 程序更新核心文件
# 更新配置数据来源于我的(原作者)github
# 因为配置数据来源于github，中国大陆用户可能访问较慢，需要挂梯子。
# v6.0.0版本开始更新配置使用Json，v6.0.0之前的版本有更新选项的版本均使用普通变量，因此v6.0.0之前版本和v6.0.0版本及之后更新配置不兼容
# 这个文件有用代码比其他多，为防止分不清if对应哪个fi等，所以标的有箭头


function Fun_Update_doumi {
clear


# 检查执行环境(SHELL)
#↓检查执行环境
if [ ! "$DEN_SHELL" = "MT" ]; then

clear

	echo -e "\033[1;31m该模块强制使用 \033[1;31mMT管理器(正式/共存/测试)拓展包\033[1;31m 环境执行！请切换至要求环境后再执行！\033[0m"

echo "========================="
Fun_GongNeng_Zong


fi
#↑检查执行环境





	echo -e "\033[36m建议挂梯子，否则中国大陆用户可能访问过慢、无法访问或被拒绝请求（本人一般使用绿茶VPN）\033[0m"

echo "========================="




# 配置数据URL
Configuration_Update_doumi="https://director4168.github.io/doumi/UpdateConfiguration.json"





# 临时目录
TMP_File_Update_configuration_doumi="$System_PWD/tmp"


# 创建临时目录，用于存放下载的配置文件
	function Fun_Shell_Mkdir {
# 先删除，防止意外
rm -rf $TMP_File_Update_configuration_doumi

# 递归创建临时目录
	echo -e "\033[1;36m创建临时目录中……\033[0m"
	mkdir -p $TMP_File_Update_configuration_doumi

#↓检查临时目录是否创建成功
	if [ ! -d "$TMP_File_Update_configuration_doumi" ]; then

	clear

		echo -e "\033[1;31m创建临时目录(\033[1;37m$TMP_File_Update_configuration_doumi\033[1;31m)失败！\033[0m"

		echo "========================="

# 防止意外创建失败，也尝试删除
rm -rf $TMP_File_Update_configuration_doumi
	Fun_GongNeng_Zong


	fi
#↑检查临时目录是否创建成功
	}
Fun_Shell_Mkdir





# 从指定的URL获取配置数据
	echo -e "\033[1;36m正在获取配置数据中(URL: \033[1;37m$Configuration_Update_doumi\033[1;36m)...\033[0m"

UpdateConfigurationFile="$TMP_File_Update_configuration_doumi/UpdateConfiguration.json"


# 下载配置
Update_Configuration_doumi="$(curl -s -H "User-Agent: Mozilla/5.0" "$Configuration_Update_doumi")"

# 检查是否为空
if [ "$Update_Configuration_doumi" = "" ]; then
	echo -e "\033[1;31m❌获取配置数据失败！\033[m"
	echo -e "\033[31m请确保 已连接WIFI/开启数据网络 ，且 WIFI/数据网络 可用！，或者 连接科学上网(挂梯子) 继续！\033[0m"

echo "========================="

rm -rf $TMP_File_Update_configuration_doumi
Fun_GongNeng_Zong


fi

echo "========================="




# 提取json数据（防止没有jq，所以使用grep）
# 下载链接
download_URL="$(echo "$Update_Configuration_doumi" | grep -oP '"download_URL"\s*:\s*"\K[^"]+')"
# 版本
Version="$(echo "$Update_Configuration_doumi" | grep -oP '"Version"\s*:\s*"\K[^"]+')"
# 版本号
Version_B="$(echo "$Update_Configuration_doumi" | grep -oP '"Version_B"\s*:\s*"\K[^"]+')"
# 源码压缩包的SHA256哈希值，为了绝对的兼容性256用wty表示，但配置数据中仍为256
ZIP_SHAwty="$(echo "$Update_Configuration_doumi" | grep -oP '"ZIP_SHA256"\s*:\s*"\K[^"]+')"
# 通知/公告
Notice="$(echo "$Update_Configuration_doumi" | grep -oP '"Notice"\s*:\s*"\K[^"]+')"
# 源数据
Configuration_FileText_Data=$(<"$UpdateConfigurationFile")

# 提取完了，那就把配置文件删除掉吧(又重新换回不落地了
#rm -r $UpdateConfigurationFile





	echo -e "\033[1;32m已获取配置数据
\033[1;33m通知/公告: \033[1;36m$Notice\033[0m
"

	echo -e "\033[1;37m下载链接: \033[0m$download_URL
\033[1;37m版本: \033[0m$Version
\033[1;37m版本号: \033[0m$Version_B
\033[1;37m程序压缩包SHA256: \033[0m$ZIP_SHAwty
"

# 防止显示的源数据可能包含\n、\033等内容
	echo -e "\033[1;37m源数据: \033[0m";echo "$Update_Configuration_doumi"

echo "========================="



# 提示对比
	echo -e "当前版本: \033[1;37m$SV\033[0m  最新配置数据中的版本: \033[1;37m$Version\033[0m
当前版本号: \033[1;37m$SVN\033[0m  最新配置数据中的版本号: \033[1;37m$Version_B\033[0m
最新程序压缩包 SHA256: \033[1;37m$ZIP_SHAwty\033[0m"





#↓根据版本号判断是否需要更新
if [ ! "$Version_B" -gt "$SVN" ]; then
echo "========================="

	echo -e "\033[1;32m已是最新版，无需更新\033[0m"

# 清理临时目录
rm -rf $TMP_File_Update_configuration_doumi

echo "========================="

rm -rf $TMP_File_Update_configuration_doumi
Fun_GongNeng_Zong


#↓根据版本号判断是否需要更新
else
echo "========================="

	echo -e "\033[1;36m检测到最新版$Version($Version_B)
\033[0m"

		echo -en "下载链接: $download_URL
输入\033[1;37mY\033[0m下载(否则不下载): "
		read YN_Download_doumi

#↓判断用户的输入来执行是否下载
	if [ "$YN_Download_doumi" = "Y" ] || [ "$YN_Download_doumi" = "y" ]; then
# 下载程序
	echo -e "\033[1;36m下载中……\033[0m"

	curl -s -o "$TMP_File_Update_configuration_doumi/doumi.zip" "$download_URL" || {
		echo -e "\033[1;31m❌下载失败！请自行前往\033[1;37mhttps://wwc.lanzouq.com/b00l1vkp5a\033[1;31m(\033[1;33m提取码: \033[1;37m0708\033[1;31m)下载\033[1;36m或\033[1;37mhttps://director4168.github.io/doumi/doumi.zip\033[1;31m下载\033[m"

	echo "========================="

	rm -rf $TMP_File_Update_configuration_doumi
	Fun_GongNeng_Zong

	}

	echo -e "\033[1;32m下载完成\033[0m"

echo "========================="


#↓判断用户的输入来执行是否下载
	else
	echo "========================="

		echo -e "\033[1;31m由于输入的非“Y”或“y”，故不下载\033[0m"

	echo "========================="

	rm -rf $TMP_File_Update_configuration_doumi
	Fun_GongNeng_Zong


#↓判断用户的输入来执行是否下载
	fi










# 解码
# 从v6.0.0版本弃用把程序压缩包Base64编码
#base64 -d $TMP_File_Update_configuration_doumi/doumi.base64 > $TMP_File_Update_configuration_doumi/doumi.zip


# 校验下载到本地的压缩包和云端配置中SHA256哈希值
# 浅浅的考虑一下，这个校验就不单独放到一个文件里了
function Fun_Check_SHAwty_Update {
	echo -e "\033[1;36m正在校验本地文件SHA256……\033[0m"
# 获取下载到本地的压缩包中的SHA256哈希值
Local_ZIP_SHAwty="$(sha256sum $TMP_File_Update_configuration_doumi/doumi.zip | awk '{print $1}')"

#	echo -e "\033[1;37m下载到本地的文件SHA256: $Local_ZIP_SHAwty\n云端SHA256: $ZIP_SHAwty"

# 开始校验
#↓SHA256校验
	if [ "$Local_ZIP_SHAwty" = "$ZIP_SHAwty" ]; then
		echo -e "\033[1;32m校验完成: \033[1;36m下载到本地的文件与云端中的SHA256相同，下载到的文件几乎绝对是原版\033[0m"

	echo "========================="


#↓SHA256校验
	else
		echo -e "\033[1;32m校验完成: \033[echo "========================="36m下载到本地的文件与云端中的SHA256不同，下载到的文件可能不是原版\033[0m"

	Risk_Update="Y"

			echo -en "\033[31m输入“\033[1;37mY\033[1;31m”继续: \033[0m"
			YN_Risk_Update

# 判断用户在可能有风险的时候是否继续下一步
#↓可能有风险，检测是否继续
		if [ "$YN_Risk_Update" = "Y" ] || [ "$YN_Risk_Update" = "y" ]; then
			echo -e "\033[31m已继续\033[0m"

		echo "========================="


#↓可能有风险，检测是否继续
		else
		clear
		echo -e "\033[36m已返回菜单\033[0m"

# 删除临时目录
		rm -rf $TMP_File_Update_configuration_doumi
# 返回至主菜单
		Fun_GongNeng_Zong

		echo "========================="


#↓可能有风险，检测是否继续
		fi

	echo "========================="


#↓SHA256校验
	fi

}
# 启用校验，如果不想启用则把下面那一行给注释化
Fun_Check_SHAwty_Update





# 将下载好的最新版本解压
	echo -e "\033[1;36m正在解压中\033[0m"
  unzip -q -o $TMP_File_Update_configuration_doumi/doumi.zip -d $System_PWD/



	echo -e "\033[1;32m更新并已解压完成(几乎绝对)\033[0m"

echo "========================="





# 清理临时目录
	echo -e "\033[1;36m正在清理临时目录\033[0m$TMP_File_Update_configuration_doumi"
rm -rf $TMP_File_Update_configuration_doumi

# 是否清理成功
	if [ -d "$TMP_File_Update_configuration_doumi" ]; then
		echo -e "\033[33m清理临时目录\033[1;37m$TMP_File_Update_configuration_doumi\033[1;33m失败，请手动删除(带临时目录用于存放配置数据和下载到的源文件)\033[0m"


	fi




	exit 7;


#↓根据版本号判断是否需要更新
fi

# 再清除一遍临时目录
rm -rf $TMP_File_Update_configuration_doumi
}

#Fun_Update_doumi