#!/system/bin/sh

#==========Copyright statement==========
# (C) 2025-20XX director_Carter All Rights Reserved.

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#====================

#==========联系方式 | Contact Information==========

#个人网站 | Personal website
# https://director4168.github.io

#哔哩哔哩 | BiliBili
# 昵称 | Name: director_Carter
# UID: 1113918991
# 主页 | Home page: https://b23.tv/tk7CcWA

### MT论坛 | MT Forum
# 昵称 | Name: director_mark
# UID: 134138
# 主页 | Home page: https://bbs.binmt.cc/home.php?mod=space&uid=134138&do=profile&mobile=2

#QQ
# 2705722903
# 1316983035

#邮箱 | Email
# 2705722903@qq.com
# 1316983035@qq.com
#====================

#==========温馨提醒 | Warm Reminder==========

#中文
# 原作者没有义务承担因您使用本程序而导致的任何风险与责任。
# 所有文件均采用 MPL-2.0 开源协议（详见项目中的 `LICENSE` 与 `NOTICE.md` 文件）。
# 如需修改，请严格遵守 MPL-2.0 开源协议的要求。
# 本程序仅供娱乐、学习与参考。

#English
# The original author has no obligation to assume any risks and responsibilities caused by your use of this program.
# All files adopt the MPL-2.0 open source license (see the `LICENSE` and `NOTICE.md` files in the project for details).
# If you modify the work, please strictly comply with the terms of the MPL-2.0 open source agreement.
# This program is for entertainment, learning, and reference purposes only.
#====================





# 豆米 shell文件首次创建于: 2025-3-22 13:41
# 更新记录存放于同压缩包中 更新日志.txt 文件
# 自4.0.0版本(SemVer标准格式)起，更新日志仅保留当前版本x.x.x，但也会保留x.x.x-x

# ==========豆米 各数据存放位置==========
# 默认数据目录: /storage/emulated/0/DouMi/Data/
# 默认用户数据目录: /storage/emulated/0/DouMi/.user/
#====================

#==========错误状态码分类==========
# 1: 文件冲突
# 2: 文件(如密码、用户名)/夹 保存失败
# 3: 没有所需 文件(如密码、用户名)/夹(如用户目录、数据目录)
# 4: 输入的内容验证失败(如验证密码)
# 5: 数据保存后退出以重新加载新数据
# 6: 输入/修改 的内容非法或不被允许
# 7: 功能性退出
#====================

clear


# 顺序以先后添加排序（初始）
# 检测当前执行目录并赋值
System_PWD=$(pwd)
# 把功能文件夹合并到执行目录变量
FE="$System_PWD/Function_Expansion"
# 选择功能变量
OF="$FE/Options_Function"
# 属性
P="$System_PWD/Property"
# 注册/登录
RL="$FE/Register_Login"
# 手动自检更新
U="$System_PWD/Update"


# 获取当前文件名
DouMi_Name="$(basename "$0")"

# 引入所需文件
# 格式: source 要引入的文件位置
# 顺序已先后添加排序（初始）
# 调用/注册/登录
source $RL/RAL.sh
source $RL/Register.sh
source $RL/Login.sh
# 检测.User
source $FE/DUF.sh
# 作者和更新介绍
source $FE/AAUI.sh
# 时间和动态版权
source $FE/TADC.sh
# 执行环境检测&Root执行状态
source $FE/TAD.sh
# 换行键继续
source $FE/LBKC.sh
# 选择非法提示函数
source $FE/Error/STIPF.sh
# 返回主菜单(通用)
source $FE/RTMM.sh

# 选择功能
# 账号操作
source $OF/AccountOperation.sh
# 终端
source $OF/Terminal.sh
# 退出
source $OF/Exit.sh

# 工具箱
source $OF/Toolbox.sh

# AI
source $OF/AI.sh

# 属性
source $P/Version.prop
source $P/CompletionTime.prop


# 更新
source $U/Update_doumi.sh


# 检查是否有.User
Fun_FE_DUF


# 如需修改请修改属性版本文件Version.prop，位于/Propertf/
	echo -e "版本: \033[1;37m$SV\033[0m"
	echo -e "版本号: \033[1;37m$SVN\033[0m"
	echo -e "编写时间: \033[1;37m$PTOTV\033[0m"
	echo "$DouMi_Name"


# 作者和更新介绍
Fun_FE_AAUI


# 时间和动态版权
Fun_FE_TADC


# 检测执行环境&Root执行状态
Fun_FE_TAD


# 换行键继续
Fun_FE_LBKC


# 注册/登录
Fun_RL_RAL


clear

	echo "<DouMi> $User_NiCheng_Data，欢迎回来。"


# 选择非法提示函数
Fun_FE_STIPF




# 选择功能函数
function Fun_GongNeng_Zong {


	echo "<DouMi> $User_NiCheng_Data，请从下列选项中选择一个操作。"

# 菜单选项
PS3="输入序号: "
select menu in 检查更新 账号操作 ROOT终端与拓展包终端 工具箱 青云客AI对话 退出脚本;do
case $REPLY in 
1)
# 检查更新
Fun_Update_doumi





  ;;
2)
# 账号操作
Fun_OF_AO





  ;;
3)
# 终端
Fun_OF_T





  ;;
4)
# 工具箱
#source $OF/Toolbox.sh
Fun_OF_TO





  ;;
5)
# AI(青云客)
Fun_OF_AI_Z





  ;;
6)
# 退出脚本
Fun_OF_Exit





  ;;
*)
# 选择非法-主菜单
clear

Fun_GongNeng_FeiFa

esac
done

}
# 运行操作选择
Fun_GongNeng_Zong


#==========Copyright statement==========
# Copyright (C) 2025-20XX director_Carter. <http://director4168.github.io   https://b23.tv/tk7CcWA>

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#====================